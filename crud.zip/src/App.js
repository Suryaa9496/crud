import RestApi from "./restapi";

function App() {
  return (
    <div className="App">
      <RestApi/>
    </div>
  );
}

export default App;
